from django.apps import AppConfig


class WordConfig(AppConfig):
    name = 'word'
