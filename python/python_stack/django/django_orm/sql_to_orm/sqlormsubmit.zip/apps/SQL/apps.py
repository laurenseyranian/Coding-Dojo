from django.apps import AppConfig


class SqlConfig(AppConfig):
    name = 'SQL'
